﻿using System;

namespace Day2
{
    class Day2
    {
        public static void Main(string[] args)
        {
            //--------------Part 1------------------
            //--1
            /*
             * Declare two variables x and y 
             * Declare variable sum = x + y
             * print sum
            */
            //declare variable x and assign it with 10
            int x1 = 10;
            //declare variable y and assign it with 20
            int y1 = 20;
            //declare variable sum and assign it with x + y
            int sum = x1 + y1; 
            //print sum (x + y)
            Console.WriteLine(sum);
            //Shortcut to comment ==> ctrl + k + c
            //Shortcut to ubcomment => ctrl + k + u
            //We can also use (ctrl + ظ to) cooment and uncomment

            //--2
            //10 must be without quotes
            //int x2 = "10"; ==> wrong
            int x2 = 10; // ==> Correct

            //C in Console must be capital
            //console.WriteLine(x + y); ==> wrong
            //Console.WriteLine(x + y);// ==> Correct

            /*
               Runtime error: error occurs during the execution of a program. 
               These errors are typically caused by invalid operations or situations that the compiler cannot catch
            */
            //Example: divide by zero
            int num1 = 5;
            int num2 = 0;
            //int num3 = num1 / num2;
            //Console.WriteLine(num3);

            /*
                Logical error: error is a mistake in the program's logic that causes it to behave incorrectly
                but does not produce a runtime error or crash. The program runs, but the output is not what you intended.
            */
            //Example:
            int number = 7;
            if (number < 10)
            {
                Console.WriteLine("Number is greater than 10");
            }
            else
            {
                Console.WriteLine("Number is less than 10");
            }

            //--3
            string fullName = "Ahmed Ragab";
            int age = 21;
            decimal salary = 70000m;
            bool isStudent = true;
            //We use name conventio to make the code clean, readable, and maintainable

            //--4
            Person personOne = new Person { Name = "Ahmed"};
            Person personTwo = personOne;
            Console.WriteLine("Before");
            Console.WriteLine($"Person one name: {personOne.Name}");
            Console.WriteLine($"Person two name: {personTwo.Name}");
            personTwo.Name = "Mohamed";
            Console.WriteLine("After");
            Console.WriteLine($"Person one name: {personOne.Name}");
            Console.WriteLine($"Person two name: {personTwo.Name}");
            //Value type: are allocated memory on the stack
            //Reference type: are allocated memory on the heap, while the reference (a pointer to the heap memory) is stored on the stack.

            //--5
            //int x = 15, y = 4;
            //Console.WriteLine($"Sum = {x + y}");
            //Console.WriteLine($"Difference = {x - y}");
            //Console.WriteLine($"Product = {x * y}");
            //Console.WriteLine($"Division = {x / y}");
            //Console.WriteLine($"Remainder = {x % y}");

            //The output of this code is 2 because the remainder of (2 % 7) is 2
            int a = 2, b = 7; 
            Console.WriteLine(a % b);

            //--6
            int givenNumber = int.Parse(Console.ReadLine());
            if (givenNumber > 10 && givenNumber % 2 == 0)
            {
                Console.WriteLine("The given number is greater then 10 and even");
            }
            //&&: don't check the second condition if the first is false
            //&: chack all conditions
            //So && is better performance

            //--7
            double d = Convert.ToDouble(Console.ReadLine());
            //int number1 = d;//An error occurs in implicit casting
            int number2 = (int)d;//No erros occur in explicit casting
            //We use explicit casting when convert from double to int because double range is bigger than in range

            //--8
            //Console.Write("Enter you age: ");
            //int yourAge = int.Parse(Console.ReadLine());
            //if (yourAge > 0)
            //{
            //    Console.WriteLine("Valid Age");
            //}
            //else
            //{
            //    Console.WriteLine("Invalid age");
            //}
            //If input is invalid we get FormatException
            //To handle this we can use TryParse() instead of Parse()
            int yourAge;
            Console.Write("Enter you age: ");
            while (!(int.TryParse(Console.ReadLine(), out yourAge)))
            {
                Console.Write("Invalid age please enter your age again: ");
            }
            if (yourAge > 0)
            {
                Console.WriteLine("Valid Age");
            }
            else
            {
                Console.WriteLine("Invalid age");
            }

            //--9
            //postfix increment
            int p = 5;
            int o = p++;
            Console.WriteLine($"p = {p}, o = {o}");
            //prefix increment
            int i = 5;
            int k = ++i;
            Console.WriteLine($"i = {i}, k = {k}");

            int x = 5; 
            int y = ++x + x++;
            //the values of x = 7 because we use prefix increment one time and postfixe increment one time
            //y = 6 + 6 = 12
        }
    }
    class Person
    {
        public string Name { get; set; }
    }
}
